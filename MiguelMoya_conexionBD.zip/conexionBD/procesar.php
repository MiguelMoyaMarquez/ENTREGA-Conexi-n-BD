<?php
$db_host = "localhost:3308";
$db_name = "form_bd";
$db_user = "root";
$db_pass = "";

$conexion = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (mysqli_connect_errno()) {
    echo "Falo al conectar con la base de datos";
    exit();
}

$name = $_POST["nombre"];
$apellido = $_POST["apellido"];
$email = $_POST["email"];
$fechaNac= $_POST["fechaNac"];
$pass= $_POST["pass"];

$pass = password_hash($pass, PASSWORD_DEFAULT);

//$sql = "INSERT INTO usuarios (nombre, apellido, email, fecha_nac, contra) VALUES ('$nombre', '$apellido', '$email', '$fechaNac', '$pass')";
$sql = "INSERT INTO `usuarios`(`nombre`, `apellido`, `email`, `fecha_nac`, `contra`) VALUES ('$name','$apellido','$email','$fechaNac','$pass')";



mysqli_query($conexion, $sql);

echo "Datos insertados correctamente";

mysqli_close($conexion)

    ?>